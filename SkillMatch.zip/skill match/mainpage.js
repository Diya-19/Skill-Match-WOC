import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import {getAuth, onAuthStateChanged, signOut, updateProfile} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
import{getFirestore, getDoc, doc, updateDoc,collection, query, where, getDocs,arrayUnion, arrayRemove } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js"


const firebaseConfig = {
    apiKey: "AIzaSyCx30k0l8ayKsggubaof9xuHipqvAcsmzQ",
    authDomain: "login-form-73bcc.firebaseapp.com",
    projectId: "login-form-73bcc",
    storageBucket: "login-form-73bcc.firebasestorage.app",
    messagingSenderId: "185175078918",
    appId: "1:185175078918:web:34a38a8a94d8be370ceb87"
  };
 
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);

  const auth=getAuth();
  const db=getFirestore();


  
  

  function showMessage(message, divId){
    var messageDiv=document.getElementById(divId);
    messageDiv.style.display="block";
    messageDiv.innerHTML=message;
    messageDiv.style.opacity=1;
    setTimeout(function(){
        messageDiv.style.opacity=0;
    },5000);
 }

 


document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('search-input');
    const Filter = document.querySelector(".filterDropdown select option:checked");
    
    //const Filter = document.querySelector('selectFilter').value.trim() ;
    
   
   
    
    // Toggle menu on small screens
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  
    // Search button functionality
    searchBtn.addEventListener('click', () => {
      const queryInput = searchInput.value.trim()//.toLowerCase();
      if (queryInput.trim() === "") {
        alert("Please enter a search term!");
        return;
      }
      if (queryInput) {
        // Redirect to the results page with search term as a query parameter
       window.location.href = `resultpage.html?query=${encodeURIComponent(queryInput)}`; 
      }
      
     });
    });


window.onload = function() {
  // Get search term from URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const query = urlParams.get('query');
  const otherUserID = urlParams.get('id');
 
  const Filter = urlParams.get('filter');
  
  

  if (query) {
    // Perform Firebase query
    searchFirebase(query,null);
  }
  if (otherUserID){
    
    globalThis.otherUserID = otherUserID;
    giveEndorsement(otherUserID );
  }
};


function searchFirebase(queryInput, Filter){
  const resultsContainer = document.getElementById('results');
        let q = query(collection(db, "users"), where("firstName", "==", queryInput));
       
        if (Filter == null){
          Filter ="First Name";
        }
        if (Filter == "First Name"){
         q = query(collection(db, "users"), where("firstName", "==", queryInput));
        }
  
        if (Filter == "Last Name"){
           q = query(collection(db, "users"), where("lastName", "==", queryInput));
         }
  
        if (Filter == "Skills"){
             q = query(collection(db, "users"), where("skills", "==", queryInput));}
  
        if (Filter == "Email"){
               q = query(collection(db, "users"), where("email", "==", queryInput));}  
              
        if (Filter == "Phone No."){
                q = query(collection(db, "users"), where("phone", "==", queryInput));}
    
        if (q== null){
          showMessage('Please choose a filter', 'filterMessage');
          return;
        }
        resultsContainer.innerHTML = '';
       
        const querySnapshot = getDocs(q).then((docSnapshot) => {
          
         
          docSnapshot.forEach(doc => {
           
            const item = doc.data();
            const itemId = doc.id; // Get the document ID (unique ID in Firestore)
            const resultItem = document.createElement('div');
            resultItem.className = 'result-item';
    
            resultItem.innerHTML = `
              <img src="${item.imageUrl || 'profilepic.jpeg'}" alt="${item.firstName}">
              <h3>${item.firstName} ${item.lastName}</h3>
              
              <p class="email">Email: ${item.email}</p>
              <p class="skills">Skills: ${item.skills}</p>
              <p class="phone">Contact Details: 91+${item.phone}</p>
              <a href="viewOtherProfile.html?id=${encodeURIComponent(itemId)}">Give Endorsements</a>
            `;
            
            resultsContainer.appendChild(resultItem);
         
          });
  
          if (docSnapshot.empty){
            
            alert//to do alert
          }
      });
  
    }    
  

  

  
function giveEndorsement(otherUserID){
  if (otherUserID == null){
    showMessage('This user is not found','profileNotFound');
   
    return;
  }
  if (otherUserID!= null){
   
    const giveEndorsementBtn = document.getElementById('giveEndorsementBtn');
    giveEndorsementBtn.addEventListener('click', () => {
      event.preventDefault();
      const db=getFirestore();
      
      const docRef=doc(db, "users", otherUserID);
     
      const updatedEndorsement = document.getElementById('endorse').value;
     
      updateDoc(docRef, {
        
        endorsements:  arrayUnion(updatedEndorsement)
        })
        .then(() => {})
        .catch((error) => {
          if (error instanceof FirebaseError) {
              return {
                  error: e.message
              };
          }
          console.error("Error updating profile: ", error);
          alert("Failed to update profile.");
        }  )

    });
    
  }
 
}


document.getElementById("profileBtn").addEventListener("click", function() {
 
    window.location.href = "profilepage.html";
    
  });

document.getElementById("availabilityBtn").addEventListener("click", function() {
 
    window.location.href = "availability.html";
   
  });

document.getElementById("homeBtn").addEventListener("click", function() {
    window.location.href = "mainpage.html";
  });
document.getElementById("endorsementBtn").addEventListener("click", function() {
    window.location.href = "endorsement.html";
  });
  
document.addEventListener('DOMContentLoaded', function () {
    const cardContainer = document.querySelector('.card-container');

    // Function to check if the user has scrolled to the bottom
    function loadCardsOnScroll() {
        const bottomOfPage = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight;

        // If the user has reached the bottom of the page, show the cards
        if (bottomOfPage) {
            cardContainer.classList.add('show');
            // Remove the event listener once the cards are displayed
            window.removeEventListener('scroll', loadCardsOnScroll);
        }
    }

    // Initially check if the user is at the bottom when the page is loaded
    loadCardsOnScroll();

    // Listen for scroll events to load the cards when reaching the bottom of the page
    window.addEventListener('scroll', loadCardsOnScroll);
});



document.getElementById('giveEndorsementBtn').addEventListener('click', function() {
  // Get the endorsement value
  const endorsementText = document.getElementById('endorse').value;

  if (endorsementText.trim() !== "") {
    // Show the modal with a success message
    document.getElementById('endorsementModal').style.display = 'block';
    document.getElementById('modalMessage').textContent = "Your endorsement: \"" + endorsementText + "\" has been submitted!";
    
    // Clear the input field
    document.getElementById('endorse').value = "";
  } else {
    // Show a warning if no endorsement text is provided
    document.getElementById('modalMessage').textContent = "Please provide an endorsement before submitting!";
    document.getElementById('endorsementModal').style.display = 'block';
  }
});

// Close the modal when the user clicks on the close button
document.getElementById('closeModal').addEventListener('click', function() {
  document.getElementById('endorsementModal').style.display = 'none';
});

// Also close the modal if the user clicks anywhere outside of it
window.onclick = function(event) {
  if (event.target === document.getElementById('endorsementModal')) {
    document.getElementById('endorsementModal').style.display = 'none';
  }
};
