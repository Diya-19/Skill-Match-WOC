import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import {getAuth, onAuthStateChanged, signOut, updateProfile} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
import{getFirestore, getDoc, doc, updateDoc,arrayUnion, arrayRemove} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js"

const firebaseConfig = {
    apiKey: "AIzaSyCx30k0l8ayKsggubaof9xuHipqvAcsmzQ",
    authDomain: "login-form-73bcc.firebaseapp.com",
    projectId: "login-form-73bcc",
    storageBucket: "login-form-73bcc.firebasestorage.app",
    messagingSenderId: "185175078918",
    appId: "1:185175078918:web:34a38a8a94d8be370ceb87"
  };
 
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);

  const auth=getAuth();
  const db=getFirestore();

  onAuthStateChanged(auth, (user)=>{
    const loggedInUserId=localStorage.getItem('loggedInUserId');
    if(loggedInUserId){
       
        const docRef = doc(db, "users", loggedInUserId);
        getDoc(docRef)
        .then((docSnap)=>{
            if(docSnap.exists()){
                const userData=docSnap.data();
                document.getElementById('loggedUserFName').innerText=userData.firstName;
                document.getElementById('loggedUserEmail').innerText=userData.email;
                document.getElementById('loggedUserLName').innerText=userData.lastName;
                document.getElementById('loggedUserSkills').innerText=userData.skills;

            }
            else{
                console.log("no document found matching id")
            }
        })
        .catch((error)=>{
            console.log("Error getting document");
        })
    }
    else{
        console.log("User Id not Found in Local storage")
    }
  })

  const logoutButton=document.getElementById('logout');

  logoutButton.addEventListener('click',()=>{
    localStorage.removeItem('loggedInUserId');
    signOut(auth)
    .then(()=>{
        window.location.href='signup.html';
    })
    .catch((error)=>{
        console.error('Error Signing out:', error);
    })
  })


  const editProfileButton = document.getElementById('editBtn');
  const submitProfileButton = document.getElementById('submitProfileButton')
  const profilePage = document.getElementById('profile');
  const editProfilePage = document.getElementById('editProfile');

  editProfileButton.addEventListener('click', (event)=>{
    event.preventDefault();
    editProfilePage.style.display="block";
    profilePage.style.display="none";

  })

  submitProfileButton.addEventListener('click', (event)=>{
    event.preventDefault();
    editProfilePage.style.display="none";
    profilePage.style.display="block";

    const updatedFirstName = document.getElementById('fNameEdit').value;
    const updatedLastName = document.getElementById('lNameEdit').value;
    const updatedSkills = document.getElementById('skillsEdit').value;
    const updatedPhone = document.getElementById('phoneEdit').value;

    const db=getFirestore();
    const auth = getAuth();
    const user = auth.currentUser;
    const docRef=doc(db, "users", user.uid);

    if (user != null ){
   
     updateDoc(docRef, {
      
        firstName: updatedFirstName,
        lastName: updatedLastName,
        skills: arrayUnion(updatedSkills),
        phone:updatedPhone
      })
      .then(() => {})
      .catch((error) => {
        if (error instanceof FirebaseError) {
            return {
                error: e.message
            };
        }
        console.error("Error updating profile: ", error);
        alert("Failed to update profile.");
      }  )
    }

    getDoc(docRef)
    .then((docSnap)=>{
        if(docSnap.exists()){
            const userData=docSnap.data();
          document.getElementById('loggedUserFName').innerText=userData.firstName;
           document.getElementById('loggedUserEmail').innerText=userData.email;
            document.getElementById('loggedUserLName').innerText=userData.lastName;
           document.getElementById('loggedUserSkills').innerText=userData.skills;
          document.getElementById('loggedUserPhone').innerText=userData.phone;
           
        }
        else{
            console.log("no document found matching id")
        }
    })
    .catch((error)=>{
        console.log("Error getting document");
       
    })

  

  })

  document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('search-input');
  
    // Toggle menu on small screens
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  
    // Search button functionality
    searchBtn.addEventListener('click', () => {
      const query = searchInput.value.trim();
      if (query) {
        alert(`Searching for: ${query}`);
        searchInput.value = '';
      }
    });
  });


  document.getElementById("profileBtn").addEventListener("click", function() {
    window.location.href = "profilepage.html";
  });

  document.getElementById("availabilityBtn").addEventListener("click", function() {
    window.location.href = "availability.html";
  });
  
  document.getElementById("homeBtn").addEventListener("click", function() {
    window.location.href = "mainpage.html";
  });
  
  document.getElementById("endorsementBtn").addEventListener("click", function() {
    window.location.href = "endorsement.html";
  });
