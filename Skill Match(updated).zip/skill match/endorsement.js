import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import {getAuth, onAuthStateChanged, signOut, updateProfile} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
import{getFirestore, getDoc, doc, updateDoc} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js"

const firebaseConfig = {
    apiKey: "AIzaSyCx30k0l8ayKsggubaof9xuHipqvAcsmzQ",
    authDomain: "login-form-73bcc.firebaseapp.com",
    projectId: "login-form-73bcc",
    storageBucket: "login-form-73bcc.firebasestorage.app",
    messagingSenderId: "185175078918",
    appId: "1:185175078918:web:34a38a8a94d8be370ceb87"
  };
 
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);

 

  document.getElementById("profileBtn").addEventListener("click", function() {
    window.location.href = "profilepage.html";
  });

  document.getElementById("availabilityBtn").addEventListener("click", function() {
    window.location.href = "availability.html";
  });
  
  document.getElementById("homeBtn").addEventListener("click", function() {
    window.location.href = "mainpage.html";
  });

  document.getElementById("endorsementBtn").addEventListener("click", function() {
    window.location.href = "endorsement.html";
  });
  
  const auth=getAuth();
  const db=getFirestore();

  onAuthStateChanged(auth, (user)=>{
    const loggedInUserId=localStorage.getItem('loggedInUserId');
    if(loggedInUserId){
       
        const docRef = doc(db, "users", loggedInUserId);
        getDoc(docRef)
        .then((docSnap)=>{
            if(docSnap.exists()){
                const userData=docSnap.data();
                
                document.getElementById('loggedUserEndorsement').innerText=userData.endorsements;
               
            }
            else{
                console.log("no document found matching id")
            }
        })
        .catch((error)=>{
            console.log("Error getting document");
        })
    }
    else{
        console.log("User Id not Found in Local storage")
    }
  })

  document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    // Toggle menu on small screens
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });

   
  });
  document.getElementById("profileBtn").addEventListener("click", function() {
    console.log("redirecting to profile page");
      window.location.href = "profilepage.html";
      
    });
  
  document.getElementById("availabilityBtn").addEventListener("click", function() {
    console.log("redirecting to availability page");
      window.location.href = "availability.html";
     
    });
  
  document.getElementById("homeBtn").addEventListener("click", function() {
      window.location.href = "mainpage.html";
    });
  document.getElementById("endorsementBtn").addEventListener("click", function() {
      window.location.href = "endorsement.html";
    });