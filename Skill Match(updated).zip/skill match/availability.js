
function toggleChange() {
  var toggle = document.getElementById('toggle');
  
}

// Future Availability
const setAvailabilityBtn = document.getElementById('setAvailabilityBtn');
const availabilityList = document.getElementById('availabilityList');
const dateInput = document.getElementById('date');

setAvailabilityBtn.addEventListener('click', function () {
  const selectedDate = dateInput.value;
  
  if (selectedDate) {
    const listItem = document.createElement('li');
    listItem.textContent = `Available on: ${new Date(selectedDate).toLocaleString()}`;
    availabilityList.appendChild(listItem);
    
    // Clear the input after adding
    dateInput.value = '';
  } else {
    alert('Please select a valid date and time!');
  }
});


document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  

  // Toggle menu on small screens
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('active');
  });

  
  });



document.getElementById("profileBtn").addEventListener("click", function() {
  window.location.href = "profilepage.html";
});

document.getElementById("availabilityBtn").addEventListener("click", function() {
  window.location.href = "availability.html";
});

document.getElementById("homeBtn").addEventListener("click", function() {
  window.location.href = "mainpage.html";
});

document.getElementById("endorsementBtn").addEventListener("click", function() {
  window.location.href = "endorsement.html";
});

